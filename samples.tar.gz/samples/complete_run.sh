#!/bin/sh
dir=`dirname $0`
rm -f $dir/segmented/$SAMPLE;
$dir/../segmenter $dir/noise_removed/$SAMPLE > $dir/segmented/$SAMPLE \
    && cat $dir/segmented/output/$SAMPLE \
    | $dir/./segmented/output/to_fann_training_file.pl -alpha >> $1 

#$dir/segmented/output/train.dat
